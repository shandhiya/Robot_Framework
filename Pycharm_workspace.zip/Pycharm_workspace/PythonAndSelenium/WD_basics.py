# from selenium import webdriver
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.common.by import By
#
#
# driver = webdriver.Chrome(ChromeDriverManager().install())
# driver.implicitly_wait(5)
# driver.get("http://www.google.com")
# print(driver.title)
#
# driver.find_element(By.LINK_TEXT,'Sign in').click()

from selenium import webdriver
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager


import time

driver = webdriver.Chrome(ChromeDriverManager().install())
driver.implicitly_wait(5)
driver.maximize_window()
driver.get("http://www.google.com")
print(driver.title)
driver.find_element(By.NAME, 'q').send_keys('python')
options_list = driver.find_elements(By.CSS_SELECTOR, 'ul.G43f7e li span')
print(len(options_list))
for ele in options_list:
    print(ele.text)
    if ele.text == 'python download':
        ele.click()
        break

time.sleep(5)
# driver.close()

# driver.get("https://www.amazon.in/")
# links_list = driver.find_elements(By.TAG_NAME, 'a')
# print(len(links_list))
# for ele in links_list:
#     link_text = ele.text
#     print(link_text)
#     print(ele.get_attribute('href'))

# img_list = driver.find_elements(By.TAG_NAME,'img')
# for ele in img_list:
#     print(ele.get_attribute('src'))