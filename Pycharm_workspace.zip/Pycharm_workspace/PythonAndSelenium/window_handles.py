from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

import time

driver = webdriver.Chrome(ChromeDriverManager().install())
driver.implicitly_wait(5)
driver.maximize_window()

driver.get("https://the-internet.herokuapp.com/windows")
driver.find_element(By.LINK_TEXT, 'Click Here').click()

main_wnd = driver.current_window_handle

# chwnd = driver.window_handles[1]
# driver.switch_to.window(chwnd)
# print(driver.find_element(By.TAG_NAME, 'h3').text)
#
# driver.switch_to.window(main_wnd)

handles = driver.window_handles
size = len(handles)
print(size)
for i in handles:
    driver.switch_to.window(i)
    print(driver.title)
    if driver.title == 'Google':
        pass
