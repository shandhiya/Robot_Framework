from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

import time

options = webdriver.ChromeOptions()
# options.headless = True
# options.add_argument('--incognito')

driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
driver.implicitly_wait(5)
driver.maximize_window()
# driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth")


driver.get("http://amazon.in")
time.sleep(3)
driver.find_element(By.LINK_TEXT, 'Mobiles').click()
time.sleep(60)
print("Mobile Clicked and waited for 60 sec")
driver.back()
time.sleep(2)
driver.refresh()
time.sleep(2)
driver.forward()
time.sleep(2)
driver.close()

