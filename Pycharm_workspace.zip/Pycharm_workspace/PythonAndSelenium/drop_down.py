from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

import time

driver = webdriver.Chrome(ChromeDriverManager().install())
driver.implicitly_wait(5)
driver.maximize_window()
driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm")

drop_down = Select(driver.find_element(By.XPATH, "//select[@name='continents']"))
drop_down.select_by_index(1)
time.sleep(3)
drop_down.select_by_visible_text('Asia')
time.sleep(2)
# #
exp = driver.find_element(By.XPATH, "//input[@name='exp' and @value='3']")
exp.click()
#
time.sleep(3)
print(exp.is_selected())
#
check_box = driver.find_element(By.XPATH, "//input[@name='profession' and @value='Automation Tester']")
check_box.click()

time.sleep(2)
print(check_box.is_enabled())
#
upload = driver.find_element(By.NAME, 'photo')
upload.send_keys(r'C:\Users\40012719\Pictures\Capture.png')
print(upload.is_displayed())
#
# time.sleep(5)
driver.get_screenshot_as_file('sc1.png')
driver.get_screenshot_as_file('sc2.jpeg')
driver.save_screenshot('sc3.png')
# driver.close()
