def repeated(string):
    c = string.split(' ')
    repeat = []
    for i in c:
        if c.count(i) > 1 and i not in repeat:
                repeat.append(i)
    return repeat
word = repeated("She sells the sea shells by the sea shells shore")
print(word)
