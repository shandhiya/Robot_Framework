def format(a, b):
    list1 = []
    j = k = 0
    c = len(a) + len(b)
    for i in range(0, c):
        if len(a) < len(b):
            if i % 2 == 0 and j < len(a):
                list1.insert(i, a[j])
                j += 1
            else:
                list1.insert(i, b[k])
                k += 1
        else:
            if i % 2 == 0 or k >= len(b):
                list1.insert(i, a[j])
                j += 1
            else:
                list1.insert(i, b[k])
                k += 1
    return list1


if __name__ == '__main__':
    a = [0, 1, 2, 7, 4]
    b = [2, 4, 8, 6, 7, 8, 8, 9, 5, 4, 3]
    print(format(a, b))
