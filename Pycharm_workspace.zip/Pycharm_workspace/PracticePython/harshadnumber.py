def harshad(number):
    m = 0
    for i in str(number):
        m +=int(i)
    if int(number) % m == 0:
        print("harshad's number")
    else:
        print("not a harshad number")
harshad(input("enter the number\n"))