welcome = "i am shandhiya"
print(welcome.split())
print(welcome.split(' '))