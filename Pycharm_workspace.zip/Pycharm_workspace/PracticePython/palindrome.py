a = "malayalam"
if (a == a[::-1]):
    print("Palindrome")
else:
    print("Not a palindrome")