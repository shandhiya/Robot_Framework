def factorial(number):
    n = 1
    for i in range(1,number+1):
        print(i)
        n = n * i
    return n
fact = factorial(int(input("Enter the number\n")))
print("Factorial is ",fact)
    Click  ${system_conf_delete}
	Click  ${continue_delete_button}
	wait a bit
	Click  ${create_system}
	Click  ${search_location}
	wait for spinner
	Click  ${Asset_location_hier_plus_icon}
	Click  ${region10_value}
	Click  ${system_conf_save}
	wait a bit
	Click  ${system_conf_save}