class Bank:
    def __init__(self, amount):
        self.amount = amount

    def checkbalance(self):
        print(self.amount)

    def withdrawal(self, wd_amount):
        self.amount = self.amount - wd_amount
        print(self.amount)

    def deposit(self, dep_amount):
        self.amount = self.amount + dep_amount
        print(self.amount)


if __name__ == '__main__':
    i = 0
    amount = int(input("Enter the Initial Amount\n"))
    obj1 = Bank(amount)
    while (int(input("Press 1 to continue\n"))) != -1:
        choice = int(input("Press 1 to check balance, 2 to Withdraw, 3 to Deposit\n"))
        if choice == 1:
            obj1.checkbalance()
        elif choice == 2:
            obj1.withdrawal(int(input("enter the amount to withdraw\n")))
        elif choice == 3:
            obj1.deposit(int(input("enter the deposit amount\n")))
        else:
            print("Enter the proper choice")
