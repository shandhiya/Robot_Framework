# Copyright (c) 2021, ABB. All rights reserved, worldwide.
# This file has the environment details
# Authored by Naimisha

# -------------------------------
# URLS
# -------------------------------
genixURL = 'https://t1.qe.genix.abb.com/dacapp/dac/App/applications/All'

# Default Values
DEFAULT_TIMEOUT = 10
DEFAULT_SLEEP = 5
maxRetries = 3
windowWidth = 1920
windowHeight = 1080

# Login
userName = 'GenixQEUser2@abb.com'
password = 'Genix@euser2@1234@'

# Database Connection String
mongoDbConnectStringSrcMap = {'connection':'mongodb://cdb-genix-qe-mt-21-1-t1:tA8ezavWGQDggpZqgCt5VpqA7n5u0M6mfTUFqYr511RohRY81X6uVb99PxF4Z2mEjoFHzP20qYKeft6AiqN2Rg==@cdb-genix-qe-mt-21-1-t1.mongo.cosmos.azure.com:10255/DIAS_SHARD_DB?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdb-genix-qe-mt-21-1-t1@','database':'DIAS_SHARD_DB','collection':'AS_CR_Target_Source_Mappings'}
mongoDbConnectStringConnection = {'connection':'mongodb://cdb-genix-qe-mt-21-1-t1:tA8ezavWGQDggpZqgCt5VpqA7n5u0M6mfTUFqYr511RohRY81X6uVb99PxF4Z2mEjoFHzP20qYKeft6AiqN2Rg==@cdb-genix-qe-mt-21-1-t1.mongo.cosmos.azure.com:10255/DIAS_SHARD_DB?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdb-genix-qe-mt-21-1-t1@','database':'DIAS_SHARD_DB','collection':'AS_CR_Connection_Configuration'}
mongoDbConnectionStringEntity={'connection':'mongodb://cdb-genix-qe-mt-21-1-t1:c15MpAh1MOTxnkQeIoXX3m3Vahbp1ubLfMTshYCOXepvPZK0dGF7FY3eVxpRaEcvzb8WxVV9CXCZIdZ5vHv2Og==@cdb-genix-qe-mt-21-1-t1.mongo.cosmos.azure.com:10255/DIAS_SHARD_DB?ssl=true&ssl_cert_reqs=CERT_NONE&retrywrites=false','database':'DIAS_SHARD_DB','collection':'AS_CR_Data_Load_Configurations'}
connectionNotavailable='[]'
mappingNotavailable='[]'


# CFH API References
loginUrl = 'https://login.microsoftonline.com'
tokenPath = '/372ee9e0-9ce0-4033-a64a-c07073a91ecd/oauth2/token'
loginBody = {'grant_type':'client_credentials','client_id':'e981ebc9-4de7-449d-b851-4653f1574c26','client_secret':'Y_o-P8rwG2TVmNVglCD5YgbTzZe91~XC~m','resource':'api://e981ebc9-4de7-449d-b851-4653f1574c26'}
baseUrl = 'https://t1.qe.genix.abb.com'
userAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) Chrome/92.0.4515.159'
srcObjApi = '/cfh/services/connections/MAX001/entities'

# Users
genixUser3 = 'GenixQEUser3@abb.com'
genixUser3Pwd = "{DyQ58z/9n.g%X5="

# Default True and False values
trueVal = 'true'
falseVal = 'false'