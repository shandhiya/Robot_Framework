# try:
#     print('dfdgfg'+'\n')
#     x = float('abc123')
#     print('dfdgfg'+'\n')
# except IOError:
#     print('This code caused an IOError.')
# except ZeroDivisionError:
#     print('This code caused a ZeroDivisionError.')
# except:
#      print('An error happened.')
#      print('The end.')
a = [1, 1, 2, 3, 4, 3, 0, 0]
v = []
c = len(a)
for i in a:
    if i not in v:
        v.append(i)
        print(i)
print(v)
