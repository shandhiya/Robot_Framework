a = [1, 3, 5, 7, 9, 16, 18]
b = [2, 4, 6]
def func(a, b):
    c = min(len(a), len(b))
    li = []
    for i in range(c):
        li.append(a[i])
        li.append(b[i])
    if len(a) > len(b):
        for i in range(c, max(len(a), len(b))):
            li.append(a[i])
    else:
        for i in range(c, max(len(a), len(b))):
            li.append(b[i])
    return li
print(func(a, b))
