from functools import reduce

# def print_hi(name):
#     '''Demonstrates triple double quotes
#     docstrings and does nothing really.'''
#     print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.
#
#
# def say_hi():
#     """
#     Function to say hi
#     :return none
#    """
#     print("Hello mam")
#
# def add(*args):
#     j = 0
#     for i in args:
#         i = i+j
#         j = i
#     print(j)
#
# def addprint(a):
#     b ='dr'
#     print('hiiii',a+b)
# # See PyCharm help at https://www.jetbrains.com/help/pycharm/
#
# if __name__ == '__main__':
#     say_hi()
#     print_hi('sandy')
#     print(print_hi.__doc__)
#     help(print_hi('dfgd'))
#     print(say_hi.__doc__)
#     add(1,2,3,4,5,6,7)
#     addprint('sandy')


# def myFun(*args, **kwargs):
#     print("args: ", args)
#     print("kwargs: ", kwargs)
#
#
# # Now we can use both *args ,**kwargs
# # to pass arguments to this function :
# myFun('geeks', 'for', 'geeks', first="Geeks", mid="for", last="Geeks")
# # Lambda functions


print(list(map(lambda x: x ** 2, (1, 2, 3, 4, 5))))
print(list(map(lambda x: x > 2, (1, 2, 3, 4, 5))))
print(list(filter(lambda x: x > 2, (1, 2, 3, 4, 5))))
numbers = [1, 2, 3, 4, 2]
reduced_number = reduce(lambda x, y: x * y, numbers)
print(reduced_number)

list1 = ['Alpha', 'Beta', 'Gamma', 'Sigma']
list2 = ['one', 'two', 'three', 'six']

test = zip(list1, list2)  # zip the values
test2 = dict(test)
print(test2)
print('\nPrinting the values of zip')
for values in test:
    print(values)  # print each tuples
