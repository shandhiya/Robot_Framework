# # abstract class
#
# from abc import *
#
#
# class Polygon(ABC):
#
#     # abstract method
#     @abstractmethod
#     def sides(self):
#         pass
#
#
# class Triangle(Polygon):
#
#     def sides(self):
#         print("Triangle has 3 sides")
#
#
# class Pentagon(Polygon):
#
#     def sides(self):
#         print("Pentagon has 5 sides")
#
#
# class Hexagon(Polygon):
#
#     def sides(self):
#         print("Hexagon has 6 sides")
#
#
# class square(Polygon):
#
#     def sides(self):
#         print("I have 4 sides")
#
#     # Driver code
#
#
# t = Triangle()
# t.sides()
#
# s = square()
# s.sides()
#
# p = Pentagon()
# p.sides()
#
# k = Hexagon()
# k.sides()
# # Cannot create instance for abstract classes
# g5 = Polygon()
# g5.sides()

# Data Abstraction in Python
# The attribute won't be available outside the class and can't invoked through the object
class Employee:
    __count = 0;

    def __init__(self):
        self.__count = self.__count + 1

    def display(self):
        print("The number of employees", self.__count)


emp = Employee()
try:
    print(emp.__count)
finally:
    emp.display()
