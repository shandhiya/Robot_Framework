class Sample:
    dd = mm = 3
    yy = 2022

    def display(self, dd, mm):
        country = 'india'
        print(dd)
        print(self.mm)
        print(self.yy)
        print(country)

    def __str__(self):
        return '/'.join([str(self.dd), str(self.mm), str(self.yy)])


# creating a object
obj1 = Sample()
obj1.display(7, 8)
setattr(obj1, 'dd', 87)
print(obj1.dd)
print(obj1)
print(getattr(obj1, 'mm'))
