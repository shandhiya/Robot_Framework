import json
import yaml

f = open('example1', 'r')
content = (f.read())
print(content)
h = open('D:\Pycharm_workspace\Python_Learning\example1','r')
c =h.read()
u =h.read(10)
print(c)
print(u)