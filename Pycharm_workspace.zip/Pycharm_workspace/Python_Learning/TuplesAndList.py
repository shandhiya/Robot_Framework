# L = [1,3,5,6]
# print(L)
# L.append('f')
# print(L)
# L.append('jhgdjgh')
# print(L)
# # extend will take iterable objects
# L.extend('dsfhgf')
# print(L)
# # Working with indexes
# print(L[1:4])
# print(L[::-1])
a = [7, 5, 4, 3, 2, 9]
c = sorted(a)
print(c)
print(a)
print(max(a))
print(len(a))
print(a.index(4))
# Extend won't take intergers
# L.extend(7)
welcome = "i am shandhiya"
print(welcome.split())
print(welcome.split(' '))
print(list(range(0, 10)))
s = 'python'
print(s)
m = list(s)
print(m)
c = ''.join(list(m))
print(c)

# Tuples
p = (1, 2, 3, 4)
print(type(p))

# immutable
# p.extend(0)

# list comprehensions
l = [1, 2, 3, 4]
c = [x ** 2 for x in l]
print(c)
for ele, i in enumerate(l):
    print(ele, i)

