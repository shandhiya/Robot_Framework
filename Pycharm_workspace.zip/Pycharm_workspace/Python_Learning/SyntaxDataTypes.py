# random
import os
import random
# random will print random value from 0 to 1
print(random.random())
# randomly pics any iterable object
print(random.choice('python'))
# print current directory
print(os.getcwd())