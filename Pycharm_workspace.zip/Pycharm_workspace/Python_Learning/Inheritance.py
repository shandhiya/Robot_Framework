# # Single Inheritance
# class Animal:
#     def bark(self):
#         print("Animal Speaking")
# # child class Dog inherits the base class Animal
# class Dog(Animal):
#     def speak(self):
#         print("dog barking")
#
# d = Dog()
# d.bark()
# d.speak()
# # Single Inheritance with super()
# class Animal:
#     def bark(self):
#         print("Animal Speaking")
#
# # child class Dog inherits the base class Animal
# class Dog(Animal):
#     def bark(self):
#         super().bark()
#         print("dog barking")
# d = Dog()
# d.bark()

# Multiple Inheritance
# class Animal:
#     def __init__(self,name):
#         self.name=name
#     def speak(self):
#         print("Animal Speaking",self.name)
# class domestic:
#     def eat(self):
#         print("Domestic animal")
# # child class Dog inherits the base class Animal
# class Dog(Animal,domestic):
#     def __init__(self,animalname):
#         self.animalname=animalname
#     def bark(self):
#         print("dog barking",self.animalname,self.name)
# d = Dog('bark')
# setattr(d,'name','scs')
# # v = domestic()
# # v.eat()
# d.speak()
# d.bark()
# d.eat()

# Super in multiple inheritance
# class Animal:
#     def __init__(self,name):
#         self.name=name
#     def speak(self):
#         print("Animal Speaking",self.name)
#     def common(self):
#         print("Calling Parent1")
# class domestic:
#     def eat(self):
#         print("Domestic animal")
#     def common(self):
#         print("Calling Parent2")
# # child class Dog inherits the base class Animal
# class Dog(domestic,Animal):
#     def __init__(self,animalname):
#         self.animalname=animalname
#     def bark(self):
#         print("dog barking",self.animalname,self.name)
#     def common(self):
#         print("Calling child")
#         super().common()
# d = Dog('bark')
# setattr(d,'name','scs')
# d.common()
# d.bark()
# d.eat()

# multilevel inheritance
# class Animal:
#     def __init__(self,name):
#         self.name=name
#     def speak(self):
#         print("Animal Speaking",self.name)
# class domestic(Animal):
#     def eat(self):
#         print("Domestic animal")
# # child class Dog inherits the base class Animal
# class Dog(domestic):
#     def __init__(self,animalname,name):
#         self.animalname=animalname
#         super().__init__(name)
#     def bark(self):
#         print("dog barking",self.animalname,self.name)
# d = Dog('bark','dff')
# # setattr(d,'name','scs')
# d.speak()
# d.bark()
# d.eat()

# multilevel inheritance with super
class Animal:
    def __init__(self,name):
        self.name=name
    def speak(self):
        print("Animal Speaking",self.name)
    def bark(self):
        print("dog barking in parent class",self.animalname,self.name)
class domestic(Animal):
    def eat(self):
        print("Domestic animal")
    def bark(self):
        print(" barking in inherited class",self.animalname,self.name)
        super().bark()
# child class Dog inherits the base class Animal
class Dog(domestic):
    def __init__(self,animalname,name):
        self.animalname=animalname
        super().__init__(name)
    def bark(self):
        super().bark()
        print("dog barking",self.animalname,self.name)
        super().bark()
d = Dog('bark','dff')
setattr(d,'name','scs')
print(getattr(d,'name'))
print(hasattr(d, 'id'))
# delattr(d, 'name')
# print(d.name)
d.speak()
d.bark()
d.eat()
print(issubclass(Dog,domestic))
print(issubclass(domestic,Dog))
print(isinstance(d,Dog))
print(isinstance(d,domestic))
print(isinstance(d,Animal))