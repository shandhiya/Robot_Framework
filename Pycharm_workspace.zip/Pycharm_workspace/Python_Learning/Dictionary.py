deff = {1: 'andd', 2: 'dfd', 'dicts': 6, 9: 'sfca'}
print(deff)
print(deff.keys())
print(deff.values())
deff2 = {'keys2': 78}
deff.update(deff2)
# deleting the keys
# method 1
del deff[1]
print(deff)
# method 2
deff.pop('dicts')
print(deff)

# deleting the keys
deff.pop('dfd')
print(deff)
# country = ['TN','KA','KL']
# capital = ['salem','mysore','ti']
# print(dict(zip(country,capital)))
