# a =[12, 35, 9, 56, 24]
# Output : [24, 35, 9, 56, 12]
def swapList(newList):
    size = len(newList)
    new = newList[::-1]
    return new

# Driver code
newList = [12, 35, 9, 56, 24,98,76]
print(swapList(newList))